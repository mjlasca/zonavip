<?php
/*
 * This file is part of FacturaScripts
 * Copyright (C) 2013-2017  Carlos Garcia Gomez  neorazorx@gmail.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Controlador para modificar el perfil del usuario.
 * @author Mario Lasluisa Castaño <mjlasluisa@gmail.com>
 */

class contenido extends fs_controller
{
    public $zonavip_registros;
    public $busqueda;
    public $grupo;
    public $pago;
    public $categoria;
    public $allow;
    public $cumplesin;
    public $post;
    public $recomendaciones;
    public $comentarios;
    public $previewpost;
    public $nextpost;
    public $productoshotmart;
    

    public function __construct()
    {
        parent::__construct(__CLASS__, 'Vista Usuario', 'Contenido', false, false);
    }

    public function private_core()
    {
        $this->post = new zonavipdb();
        $this->comentarios = new comentarios();
        
        
        $this->allow = allowusuario($this->user->nick, $this->page->name);
        if($this->user->admin){
            $this->allow = 1;
        }
        
        if($this->allow != "1"){
            $this->allow = 0;
        }

        $this->productoshotmart = new hotmartuser();
        $this->productoshotmart->user = $this->user->nick;

        if(isset($_REQUEST["post"])){
            $this->comentarios->regpost = $_REQUEST["post"];
            $this->post = $this->post->get( $_REQUEST["post"]);
            $this->recomendaciones = new zonavipdb();
            $this->recomendaciones->categoriaFiltro = $this->post->categoria;
            $this->recomendaciones = $this->recomendaciones->recomendaciones($_REQUEST["post"]);

            $zona = new zonavipdb();
            $zona->categoriaFiltro = $this->post->categoria;
            $this->previewpost = $zona->get_preview($_REQUEST["post"]);
            $this->nextpost = $zona->get_next($_REQUEST["post"]);

            $historial = new historialvideos();
            $historial->regpost =$_REQUEST["post"];
            $historial->user =$this->user->nick;
            $historial->ultmod = date("Y-m-d H:i:s");
            $historial->save();
        }


        if(isset($_REQUEST["getcomentarios"])){
            $this->getcomentarios();
        }

        if(isset($_REQUEST["insertmsg"])){
            $this->insertmsg();
        }

        if(isset($_REQUEST["eliminarcomentario"])){
            $this->eliminarcomentario($_REQUEST["eliminarcomentario"]);
        }

        
    }
    
    public  function getcomentarios()
    {
        
        /// desactivamos la plantilla HTML
        $this->template = FALSE;
        $comen = new comentarios();
        $comen->regpost = $_REQUEST["post"];
        header('Content-Type: application/json');

        echo json_encode($comen->all_post());
    }

    public function insertmsg(){
        /// desactivamos la plantilla HTMLelimi
        $this->template = FALSE;
        $comen = new comentarios();
        $comen->regpost = $_REQUEST["post"];
        $comen->mensaje = $_REQUEST["insertmsg"];
        if(isset($_REQUEST["regmensaje"]))
            $comen->regmensajeresponde = $_REQUEST["regmensaje"];
        if(isset($_REQUEST["userresponse"]))            
            $comen->userresponde = $_REQUEST["userresponse"];
        $comen->ultmod = date("Y-m-d H:i:s");
        $comen->user = $_REQUEST["user"];
        $comen->save();
        header('Content-Type: application/json');

        echo json_encode($comen);
    }
    

    public function eliminarcomentario($reg){
        /// desactivamos la plantilla HTML
        $this->template = FALSE;
        $comen = new comentarios();
        $comen->reg = $reg;
        
        header('Content-Type: application/json');
        echo json_encode($comen->delete());
    }

    public function aprobaracceso($producto){
        if($producto == "Club de Macros")
            $producto = "1125293";
        if($producto == "Descargas")
            $producto = "1125294";
        $this->productoshotmart->idproducto = $producto;
        return $this->productoshotmart->all_user_producto();
        
    }
}
