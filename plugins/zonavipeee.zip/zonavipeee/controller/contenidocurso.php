<?php
/*
 * This file is part of FacturaScripts
 * Copyright (C) 2013-2017  Carlos Garcia Gomez  neorazorx@gmail.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Controlador para modificar el perfil del usuario.
 * @author Mario Lasluisa Castaño <mjlasluisa@gmail.com>
 */

class contenidocurso extends fs_controller
{
    public $zonavip_registros;
    public $busqueda;
    public $grupo;
    public $pago;
    public $categoria;
    public $allow;
    public $cumplesin;
    public $post;
    public $recomendaciones;
    public $comentarios;
    public $previewpost;
    public $nextpost;
    public $productoshotmart;
    public $curso;
    public $curso_modulos;
    public $checkvideo;
    public $nocontent;

    public function __construct()
    {
        parent::__construct(__CLASS__, 'Vista Usuario', 'contenido', false, false);
    }

    public function private_core()
    {
        $this->post = new zonavipdb();
        $this->curso = new hotmartproductos();
        $this->comentarios = new comentarios();
        $this->checkvideo = new historialvideoscursos();
        
        $this->nocontent = false;

        $this->allow = allowusuario($this->user->nick, $this->page->name);
        if($this->user->admin){
            $this->allow = 1;
        }
        
        if($this->allow != "1"){
            $this->allow = 0;
        }

        $this->productoshotmart = new hotmartuser();
        $this->productoshotmart->user = $this->user->nick;



        if(isset($_REQUEST["curso"])){


            $this->curso =  $this->curso->get_curso($_REQUEST["curso"]);
            $this->curso_modulos = $this->post->cursos_modulos($this->curso->idproducto);


            if($this->curso_modulos){
                $this->nocontent = true;

                if(isset($_REQUEST["post"]))
                    $this->comentarios->regpost = $_REQUEST["post"];
                else {
                    $_REQUEST["post"] = $this->post->modulos_lecciones("1",$this->curso->idproducto)[0]["reg"];
                    if($this->checkvideo->lastvideo($this->user->nick,$this->curso->idproducto)[0]["ult"] != "" )
                        $_REQUEST["post"] = $this->checkvideo->lastvideo($this->user->nick,$this->curso->idproducto)[0]["ult"];
                }

                $this->post = $this->post->get( $_REQUEST["post"]);
                $this->recomendaciones = new zonavipdb();
                $this->recomendaciones->categoriaFiltro = $this->post->categoria;
                $this->recomendaciones = $this->recomendaciones->recomendaciones($_REQUEST["post"]);

                $zona = new zonavipdb();
                $zona->categoriaFiltro = $this->post->categoria;
                $this->previewpost = $zona->get_preview_curso($this->post->numeroleccion,$this->post->curso);
                $this->nextpost = $zona->get_next_curso($this->post->numeroleccion,$this->post->curso);

            }
            
        }


        if(isset($_REQUEST["getcomentarios"])){
            $this->getcomentarios();
        }

        if(isset($_REQUEST["insertmsg"])){
            $this->insertmsg();
        }

        if(isset($_REQUEST["filet"])){
            $this->savefile($this->curso->idproducto ."-".$this->post->reg,$_FILES["leccionfile"]);
        }

        if(isset($_REQUEST["eliminarcomentario"])){
            $this->eliminarcomentario($_REQUEST["eliminarcomentario"]);
        }

        if(isset($_REQUEST["tiposetvideo"])){
            if($_REQUEST["tiposetvideo"] == 0)
                $this->deletvideocurso($_REQUEST["setvideocurso"]);
                if($_REQUEST["tiposetvideo"] == 1)
                $this->setvideocurso($_REQUEST["setvideocurso"]);
            
        }
        
    }

    private function savefile($post,$file){

        $ruta_fichero_origen = $file['tmp_name'];
        $extensiones = array(0=>'file/xls',1=>'file/xlsx',2=>'file/xlsm');
        $max_tamanyo = 1024 * 1024 * 8;
        $path = 'plugins/zonavipeee/view/assets/file/' .$post.'/';
        $exten = "xlsm";
        if($file['type'] == 'application/vnd.ms-excel')
           $exten = "xls";
        if($file['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
           $exten = "xlsx";
        if($file['type'] == 'application/vnd.ms-excel.sheet.macroEnabled.12')
           $exten = "xlsm";

        if (!file_exists($path)) {
            if(!mkdir($path,0777, true) ) {
                $this->new_error_msg("Error al crear directorio");
                return false;
            }
        }

        $ruta_nuevo_destino = $path. $this->user->nick.'.'.$exten;

        
        //$this->new_message("<br><br>--> ".$file['type']);
  
        //if ( in_array($file['type'], $extensiones) ) {
            
           
           if ( $file['size']< $max_tamanyo ) {
              
                 if(! move_uploaded_file ( $ruta_fichero_origen, $ruta_nuevo_destino ) ) {
                     $this->new_error_msg("Error al subir el archivo")  ;
                 }else{
                    
                    /*$this->cliente->img = $exten;
                    $this->cliente->save();                  */
                    $this->new_message("Se ha guardado el arhivo con éxito");
                 }
           }else{
               $this->new_error_msg("El archivo es demasiado grande");
           }
        //}
  
     }
    
    public  function getcomentarios()
    {
        /// desactivamos la plantilla HTML
        $this->template = FALSE;
        $comen = new comentarios();
        $comen->regpost = $_REQUEST["post"];
        header('Content-Type: application/json');
        echo json_encode($comen->all_post());
    }

    public  function setvideocurso($post)
    {
        /// desactivamos la plantilla HTML
        $this->template = FALSE;

        $historial = new historialvideoscursos();
        $historial->regpost = $post;
        $historial->user =$this->user->nick;
        $historial->ultmod = date("Y-m-d H:i:s");
        $historial->curso = $_REQUEST["curso"];
        $data = [];
        $data["state"] = false;
        if($historial->save()){
            $data["state"] = true;
        }
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    public  function deletvideocurso($post)
    {
        /// desactivamos la plantilla HTML
        $this->template = FALSE;
        $historial = new historialvideoscursos();
        $historial->regpost = $post;
        $historial->user =$this->user->nick;
        $data = [];
        $data["state"] = false;
        if($historial->delete()){
            $data["state"] = true;
        }
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    public function insertmsg(){
        /// desactivamos la plantilla HTMLelimi
        $this->template = FALSE;
        $comen = new comentarios();
        $comen->regpost = $_REQUEST["post"];
        $comen->mensaje = $_REQUEST["insertmsg"];
        if(isset($_REQUEST["regmensaje"]))
            $comen->regmensajeresponde = $_REQUEST["regmensaje"];
        if(isset($_REQUEST["userresponse"]))            
            $comen->userresponde = $_REQUEST["userresponse"];
        $comen->ultmod = date("Y-m-d H:i:s");
        $comen->user = $_REQUEST["user"];
        $comen->save();
        header('Content-Type: application/json');

        echo json_encode($comen);
    }
    

    public function eliminarcomentario($reg){
        /// desactivamos la plantilla HTML
        $this->template = FALSE;
        $comen = new comentarios();
        $comen->reg = $reg;
        
        header('Content-Type: application/json');
        echo json_encode($comen->delete());
    }

    public function aprobaracceso($producto){
        if($producto == "Club de Macros")
            $producto = "1125293";
        if($producto == "Descargas")
            $producto = "1125294";
        $this->productoshotmart->idproducto = $producto;
        return $this->productoshotmart->all_user_producto();
        
    }
}
